package ies.puerto;

public class Circulo {

    private float radio;

    public double Area (double pi, double area){

        pi = Math.PI;
        area = pi*radio;

        return area;
    }

}