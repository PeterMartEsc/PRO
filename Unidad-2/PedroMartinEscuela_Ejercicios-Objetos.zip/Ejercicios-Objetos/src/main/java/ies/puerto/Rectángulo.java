package ies.puerto;

public class Rectángulo {
    public static void main(String[] args) {


    }
}