package es.ies.puerto.PrimeraParte.Interface;

public interface IVehiculo {

    int velocidadMaxima();
}
