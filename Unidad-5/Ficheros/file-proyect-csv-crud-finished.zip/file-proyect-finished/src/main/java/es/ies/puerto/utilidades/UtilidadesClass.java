package es.ies.puerto.utilidades;

public class UtilidadesClass {
    public final String DELIMITADOR =",";
}
