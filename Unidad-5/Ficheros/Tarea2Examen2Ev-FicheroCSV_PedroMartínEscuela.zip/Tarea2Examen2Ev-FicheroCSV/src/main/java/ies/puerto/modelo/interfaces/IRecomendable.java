package ies.puerto.modelo.interfaces;

public interface IRecomendable {

    boolean recomendarProducto();

    int calcularPopularidad();
}
