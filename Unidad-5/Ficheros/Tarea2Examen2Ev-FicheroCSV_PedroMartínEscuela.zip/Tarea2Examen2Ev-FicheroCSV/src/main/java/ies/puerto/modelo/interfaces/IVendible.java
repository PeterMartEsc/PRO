package ies.puerto.modelo.interfaces;

public interface IVendible {

     float precioMaximo();

     int cantidadDisponible();
}
