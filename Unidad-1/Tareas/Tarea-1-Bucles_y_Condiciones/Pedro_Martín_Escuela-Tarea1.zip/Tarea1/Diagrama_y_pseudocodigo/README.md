<div aling="justify">

# Tarea 1

- [Descripcion](#descripcion)
- [Diagrama](#diagrama)
- [Pseudocodigo](#pseudocodigo)

## Descripcion <a name="descripcion"></a>

Desarrolle un algoritmo que permita calcular Promedio de Notas; finaliza cuando N = 0.

## Diagrama <a name="diagrama"></a>

<img src="../images/diagramaTarea1.png"/>

## Pseudocodigo <a name="pseudocodigo"></a>

- Inicio

- Declaración de Variables:

- N, nota, suma=0, media (como float)

- Pedimos por pantalla que inserten el numero de notas (N)

- Si N es 0, se acabará el programa

- Iniciamos un bucle en el cual nos pedirá que introduzcamos notas hasta que se repita N veces

- suma = suma+nota

- Cuando i sea igual a N:

- media = suma/N

- Imprime por pantalla el resultado de la media

- Fin

</div>
