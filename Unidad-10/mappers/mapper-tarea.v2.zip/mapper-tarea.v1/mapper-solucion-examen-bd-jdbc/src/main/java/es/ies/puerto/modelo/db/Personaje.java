package es.ies.puerto.modelo.db;

import java.io.Serializable;

public class Personaje implements Serializable {
}
