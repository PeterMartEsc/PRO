package ies.puerto.Interfaces;

public interface IVendible {

     float precioMaximo();

     int cantidadDisponible();
}
