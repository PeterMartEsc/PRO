package ies.puerto.Interfaces;

public interface IRecomendable {

    boolean recomendarProducto();

    int calcularPopularidad();
}
